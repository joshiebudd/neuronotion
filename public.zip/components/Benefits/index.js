import Benefits1 from "./Benefits1";
import Benefits2 from "./Benefits2";
import Benefits3 from "./Benefits3";

const NewBenefits = () => {
  return (
    <>
      <Benefits1 />
      <Benefits2 />
      <Benefits3 />
    </>
  );
};

export default NewBenefits;

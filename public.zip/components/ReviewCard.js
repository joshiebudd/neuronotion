import React from "react";
const ReviewCard = ({ jobTitle, jobDescription }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md mr-2 w-1/4 content-center items-center">
      {/* Image */}
      <div class="flex flex-row">
        <div className="mr-4">
          <img
            className="w-12 h-12 rounded-full"
            src="https://via.placeholder.com/100"
            alt="Avatar"
          />
        </div>

        {/* Name and Job */}
        <div className="flex-grow">
          <h2 className="text-xl font-semibold">John Doe</h2>
          <p className="text-gray-600">Software Engineer</p>
        </div>
      </div>
      <div class="flex flex-col  mt-2">
        {/* Star Rating */}
        <div className="flex items-center mb-2 items-center">
          <svg
            className="w-5 h-5 text-yellow-500 fill-current mr-1"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M10 1L12.2457 6.47214H18.3624L13.8149 10.4721L15.0606 15.9443L10 12.5279L4.93939 15.9443L6.18505 10.4721L1.63757 6.47214H7.75431L10 1Z" />
          </svg>
          <svg
            className="w-5 h-5 text-yellow-500 fill-current mr-1"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M10 1L12.2457 6.47214H18.3624L13.8149 10.4721L15.0606 15.9443L10 12.5279L4.93939 15.9443L6.18505 10.4721L1.63757 6.47214H7.75431L10 1Z" />
          </svg>
          <svg
            className="w-5 h-5 text-yellow-500 fill-current mr-1"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M10 1L12.2457 6.47214H18.3624L13.8149 10.4721L15.0606 15.9443L10 12.5279L4.93939 15.9443L6.18505 10.4721L1.63757 6.47214H7.75431L10 1Z" />
          </svg>
          <svg
            className="w-5 h-5 text-yellow-500 fill-current mr-1"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M10 1L12.2457 6.47214H18.3624L13.8149 10.4721L15.0606 15.9443L10 12.5279L4.93939 15.9443L6.18505 10.4721L1.63757 6.47214H7.75431L10 1Z" />
          </svg>
          <svg
            className="w-5 h-5 text-gray-300 fill-current mr-1"
            viewBox="0 0 24 24"
          >
            {/* SVG for empty star icon */}
            <path d="M12 2 L15.09 8.26 L22 9.27 L17 14.14 L18.18 21 L12 17.77 L5.82 21 L7 14.14 L2 9.27 L8.91 8.26 Z" />
          </svg>
        </div>

        {/* Job Title and Description */}
        <div className="mb-2">
          <h3 className="text-lg font-semibold mb-1">{jobTitle}</h3>
          <p className="text-gray-700">{jobDescription}</p>
        </div>

        {/* Date */}
        <div>
          <p className="text-sm text-gray-500">Posted on 23rd February 2024</p>
        </div>
      </div>
    </div>
  );
};

export default ReviewCard;

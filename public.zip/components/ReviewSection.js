import React from "react";
import ReviewCard from "./ReviewCard";

// Function to generate a random job title
function generateJobTitle() {
  const jobTitles = [
    "Software Engineer",
    "Web Developer",
    "Data Scientist",
    "UX/UI Designer",
    "Product Manager",
    "Marketing Specialist",
    "Financial Analyst",
    "HR Manager",
    "Content Writer",
    "Graphic Designer",
  ];
  const randomIndex = Math.floor(Math.random() * jobTitles.length);
  return jobTitles[randomIndex];
}

// Function to generate a random job description
function generateJobDescription() {
  const jobDescriptions = [
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
    "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
  ];
  const randomIndex = Math.floor(Math.random() * jobDescriptions.length);
  return jobDescriptions[randomIndex];
}
const ReviewSection = () => {
  return (
    <section
      id="review"
      className="pt-20 pl-20 pb-12 pr-20 content-center items-center bg-gray-100 flex flex-none
       flex-col flex-nowrap gap-5 h-min justify-start overflow-visible position-relative
        w-full"
    >
      <div class="gap-3.5 max-w-screen-sm	overflow-hidden p-10">
        <div>
          <h2 class="font-manrope text-4xl font-extrabold	tracking[-.1em] leading-10	text-center">
            What customers are saying about us.
          </h2>
        </div>
        <div class="pt-3">
          <p class="text-center font-inter text-base font-medium text-center leading-6 text-gray-700">
            Over 5,000 users have transformed their digital productivity and
            organization with Second Brain.
          </p>
        </div>
      </div>
      <div class="flex flex-row p-3 justify-between	 content-center items-center flex-wrap">
        <ReviewCard
          jobTitle={generateJobTitle()}
          jobDescription={generateJobDescription()}
        ></ReviewCard>
        <ReviewCard
          jobTitle={generateJobTitle()}
          jobDescription={generateJobDescription()}
        ></ReviewCard>
        <ReviewCard
          jobTitle={generateJobTitle()}
          jobDescription={generateJobDescription()}
        ></ReviewCard>
        <ReviewCard
          jobTitle={generateJobTitle()}
          jobDescription={generateJobDescription()}
        ></ReviewCard>
        <ReviewCard
          jobTitle={generateJobTitle()}
          jobDescription={generateJobDescription()}
        ></ReviewCard>
        <ReviewCard
          jobTitle={generateJobTitle()}
          jobDescription={generateJobDescription()}
        ></ReviewCard>
        <ReviewCard
          jobTitle={generateJobTitle()}
          jobDescription={generateJobDescription()}
        ></ReviewCard>
        <ReviewCard
          jobTitle={generateJobTitle()}
          jobDescription={generateJobDescription()}
        ></ReviewCard>
        <ReviewCard
          jobTitle={generateJobTitle()}
          jobDescription={generateJobDescription()}
        ></ReviewCard>
      </div>
    </section>
  );
};

export default ReviewSection;

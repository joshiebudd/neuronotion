import React from 'react';

const FreebieCopy = () => {
  return (
    <section className="freebie-article" style={{ textAlign: 'left' }}>

    <p>Hey ...</p>
    <br />

    <p>If you only want the gift promised in the video, click the button below to get the tool for free. There are no forms to fill for that.</p>
    <br />

 
  </section>
  );
};

export default FreebieCopy;
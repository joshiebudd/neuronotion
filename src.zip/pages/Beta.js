import React from "react";
import FreeBie from "../components/CourseCampaign/FreeBie";
import LongVideo from "../components/CourseCampaign/LongVideo";

const Beta = () => {
  return (
    <>
      <LongVideo />
      <FreeBie />
    </>
  );
};
export default Beta;

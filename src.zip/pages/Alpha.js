import React from "react";
import CourseFormAlpha from "../components/CourseCampaign/CourseFormAlpha";
import FreeBie from "../components/CourseCampaign/FreeBie";

const Alpha = () => {
  return (
    <>
      <CourseFormAlpha />
      <FreeBie />
    </>
  );
};
export default Alpha;
